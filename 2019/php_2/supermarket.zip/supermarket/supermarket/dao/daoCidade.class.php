<?php
    require_once "model/Cidade.class.php";
    require_once "db/conexao.php";
    class DaoCidade{
        public function create(){

        }
        public function read(){

        }
        public function update(){

        }
        public function delete(){
            
        }
    }
?>