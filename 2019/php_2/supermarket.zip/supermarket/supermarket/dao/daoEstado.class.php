<?php
    require_once "model/Estado.class.php";
    require_once "db/conexao.php";
    class DaoEstado{
        public function create(){

        }
        public function read(){

        }
        public function update(){

        }
        public function delete(){
            
        }
    }
?>