<?php
    require_once "model/UsuarioProduto.class.php";
    require_once "db/conexao.php";
    class DaoUsuarioProduto{
        public function create(){

        }
        public function read(){

        }
        public function update(){

        }
        public function delete(){
            
        }
    }
?>